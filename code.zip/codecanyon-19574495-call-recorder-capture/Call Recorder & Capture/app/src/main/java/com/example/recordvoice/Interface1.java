package com.example.recordvoice;

import java.util.ArrayList;

/**
 * Created by vieta on 13/9/2016.
 */

public interface Interface1 {
    public void setList(ArrayList<String> list);
}
